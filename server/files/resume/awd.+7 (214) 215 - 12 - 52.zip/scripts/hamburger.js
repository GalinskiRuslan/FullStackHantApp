const hamburger = document.querySelector(".hamburger");
const menu = document.querySelector(".menu");
const close = document.querySelector(".menu__close");
const overlayMenu = document.querySelector(".overlay_menu");
const linkMenu = document.querySelector(".menu__link");

function showMenu() {
	hamburger.addEventListener("click", () => {
		menu.classList.add("active");
		overlayMenu.classList.add("show");
		overlayMenu.classList.remove("hide");
	});
}
function hideMenu() {
	close.addEventListener("click", () => {
		menu.classList.remove("active");
		overlayMenu.classList.add("hide");
		overlayMenu.classList.remove("show");
	});
	overlayMenu.addEventListener("click", () => {
		menu.classList.remove("active");
		overlayMenu.classList.add("hide");
		overlayMenu.classList.remove("show");
	});
	linkMenu.addEventListener("click", () => {
		menu.classList.remove("active");
		overlayMenu.classList.add("hide");
		overlayMenu.classList.remove("show");
	});
}

hideMenu();
showMenu();
