const leedFormBtn = document.querySelector(".leedForm__btn");
const leedForm = document.querySelector(".leedForm");
const overlayLeedForm = document.querySelector(".overlay_leedForm");

function showModal() {
	leedForm.classList.remove("hide");
	overlayLeedForm.classList.remove("hide");
}
function closeModal() {
	leedForm.classList.add("hide");
	overlayLeedForm.classList.add("hide");
}

leedFormBtn.addEventListener("click", showModal);

overlayLeedForm.addEventListener("click", () => {
	leedForm.classList.add("hide");
	overlayLeedForm.classList.add("hide");
	console.log("click");
});
