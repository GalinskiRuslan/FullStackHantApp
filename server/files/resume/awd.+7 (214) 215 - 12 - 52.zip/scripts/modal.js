const modalWindow = document.querySelector(".modal__window");
const modalWindow2 = document.querySelector(".modal__window2");
const modalWindow3 = document.querySelector(".modal__window3");
const sertOne = document.querySelector(".sert_1");
const sertTwo = document.querySelector(".sert_2");
const sertThree = document.querySelector(".sert_3");
const imgOne = document.querySelector("#img_one");
const imgTwo = document.querySelector("#img_two");
const imgThree = document.querySelector("#img_three");
const overlay = document.querySelector(".overlay");

function showModal() {
	sertOne.addEventListener("click", () => {
		modalWindow.classList.remove("hide");
		overlay.classList.remove("hide");
		console.log("click");
	});
	sertTwo.addEventListener("click", () => {
		modalWindow2.classList.remove("hide");
		overlay.classList.remove("hide");
	});
	sertThree.addEventListener("click", () => {
		modalWindow3.classList.remove("hide");
		overlay.classList.remove("hide");
	});
}
function closeModal() {
	imgOne.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
	imgTwo.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
	imgThree.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
	overlay.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
}

showModal();
closeModal();
