////slider

// slider({
// 	container: ".news__slider",
// 	slide: ".news__slide",
// 	nextArrow: ".news__slider-next",
// 	prevArrow: ".news__slider-prev",
// 	totalCounter: "#total",
// 	currentCounter: "#current",
// 	wrapper: ".news__slider-wrapper",
// 	field: ".news__slider-inner",
// });

// function slider({
// 	container,
// 	slide,
// 	nextArrow,
// 	prevArrow,
// 	totalCounter,
// 	currentCounter,
// 	wrapper,
// 	field,
// }) {
// 	const slides = document.querySelectorAll(slide);
// 	const slider = document.querySelector(container);
// 	const prev = document.querySelector(prevArrow);
// 	const next = document.querySelector(nextArrow);
// 	const total = document.querySelector(totalCounter);
// 	const current = document.querySelector(currentCounter);
// 	const slidesWrapper = document.querySelector(wrapper);
// 	const slidesField = document.querySelector(field);
// 	const width = window.getComputedStyle(slidesWrapper).width;

// 	let slideIndex = 1;
// 	let offset = 0;

// 	// if (slides.length < 10) {
// 	// 	total.textContent = `0${slides.length}`;
// 	// 	current.textContent = `0${slideIndex}`;
// 	// } else {
// 	// 	total.textContent = slides.length;
// 	// 	current.textContent = slideIndex;
// 	// }

// 	slidesField.style.width = 100 * slides.length + "%";
// 	slidesField.style.display = "flex";
// 	slidesField.style.transition = "0.5s all";

// 	slidesWrapper.style.overflow = "hidden";

// 	slides.forEach((slide) => {
// 		slide.style.width = width;
// 	});

// 	slider.style.position = "relative";

// const indicators = document.createElement("ol");
// const dots = [];

// indicators.classList.add("carousel-indicators");
// indicators.style.cssText = `
// 	position: absolute;
// 	right: 0;
// 	bottom: 0;
// 	left: 0;
// 	z-index: 15;
// 	display: flex;
// 	justify-content: center;
// 	margin-right: 15%;
// 	margin-left: 15%;
// 	list-style: none;
// `;
// slider.append(indicators);

// for (let i = 0; i < slides.length; i++) {
// 	const dot = document.createElement("li");
// 	dot.setAttribute("data-slide-to", i + 1);
// 	dot.style.cssText = `box-sizing: content-box;
// 		flex: 0 1 auto;
// 		width: 30px;
// 		height: 6px;
// 		margin-right: 3px;
// 		margin-left: 3px;
// 		cursor: pointer;
// 		background-color: #fff;
// 		background-clip: padding-box;
// 		border-top: 10px solid transparent;
// 		border-bottom: 10px solid transparent;
// 		opacity: 0.5;
// 		transition: opacity 0.6s ease;
// 	`;
// 	if (i == 0) {
// 		dot.style.opacity = 1;
// 	}
// 	indicators.append(dot);
// 	dots.push(dot);
// }

// next.addEventListener("click", () => {
// 	if (offset == +width.replace(/\D/g, "") * (slides.length - 1)) {
// 		offset = 0;
// 	} else {
// 		offset += +width.replace(/\D/g, "");
// 	}
// 	slidesField.style.transform = `translateX(-${offset}px)`;

// 	if (slideIndex == slides.length) {
// 		slideIndex = 1;
// 	} else {
// 		slideIndex++;
// 	}

// if (slides.length < 10) {
// 	current.textContent = `0${slideIndex}`;
// } else {
// 	current.textContent = slideIndex;
// }

// dots.forEach((dot) => {
// 	dot.style.opacity = ".5";
// });
// dots[slideIndex - 1].style.opacity = "1";
// });

// prev.addEventListener("click", () => {
// 	if (offset == 0) {
// 		offset = +width.replace(/\D/g, "") * (slides.length - 1);
// 	} else {
// 		offset -= +width.replace(/\D/g, "");
// 	}
// 	slidesField.style.transform = `translateX(-${offset}px)`;

// 	if (slideIndex == 1) {
// 		slideIndex = slides.length;
// 	} else {
// 		slideIndex--;
// 	}

// if (slides.length < 10) {
// 	current.textContent = `0${slideIndex}`;
// } else {
// 	current.textContent = slideIndex;
// }

// dots.forEach((dot) => {
// 	dot.style.opacity = ".5";
// });
// dots[slideIndex - 1].style.opacity = "1";
// });

// dots.forEach((dot) => {
// 	dot.addEventListener("click", (e) => {
// 		const slideTo = +e.target.getAttribute("data-slide-to");

// 		slideIndex = slideTo;
// 		offset = +width.replace(/\D/g, "") * (slideTo - 1);

// 		slidesField.style.transform = `translateX(-${offset}px)`;

// 		// if (slides.length < 10) {
// 		// 	current.textContent = `0${slideIndex}`;
// 		// } else {
// 		// 	current.textContent = slideIndex;
// 		// }

// 		dots.forEach((dot) => {
// 			dot.style.opacity = ".5";
// 		});
// 		dots[slideIndex - 1].style.opacity = "1";
// 	});
// });
// }

//slider end

//modal

const modalWindow = document.querySelector(".modal__window");
const modalWindow2 = document.querySelector(".modal__window2");
const modalWindow3 = document.querySelector(".modal__window3");
const sertOne = document.querySelector(".sert_1");
const sertTwo = document.querySelector(".sert_2");
const sertThree = document.querySelector(".sert_3");
const imgOne = document.querySelector("#img_one");
const imgTwo = document.querySelector("#img_two");
const imgThree = document.querySelector("#img_three");
const overlay = document.querySelector(".overlay");

function showModal() {
	sertOne.addEventListener("click", () => {
		modalWindow.classList.remove("hide");
		overlay.classList.remove("hide");
		console.log("click");
	});
	sertTwo.addEventListener("click", () => {
		modalWindow2.classList.remove("hide");
		overlay.classList.remove("hide");
	});
	sertThree.addEventListener("click", () => {
		modalWindow3.classList.remove("hide");
		overlay.classList.remove("hide");
	});
}
function closeModal() {
	imgOne.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
	imgTwo.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
	imgThree.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
	overlay.addEventListener("click", () => {
		modalWindow.classList.add("hide");
		modalWindow2.classList.add("hide");
		modalWindow3.classList.add("hide");
		overlay.classList.add("hide");
	});
}

showModal();
closeModal();

//hamburger
const hamburger = document.querySelector(".hamburger");
const menu = document.querySelector(".menu");
const close = document.querySelector(".menu__close");
const overlayMenu = document.querySelector(".overlay_menu");

function showMenu() {
	hamburger.addEventListener("click", () => {
		menu.classList.add("active");
		overlayMenu.classList.add("show");
		overlayMenu.classList.remove("hide");
	});
}
function hideMenu() {
	close.addEventListener("click", () => {
		menu.classList.remove("active");
		overlayMenu.classList.add("hide");
		overlayMenu.classList.remove("show");
	});
	overlayMenu.addEventListener("click", () => {
		menu.classList.remove("active");
		overlayMenu.classList.add("hide");
		overlayMenu.classList.remove("show");
	});
}
hideMenu();
showMenu();
