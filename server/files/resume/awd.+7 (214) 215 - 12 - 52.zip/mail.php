<?php
$to = "manager@mfohelp.kz";
$from = "manager@mfohelp.kz";
$subject = "Заголовок письма";

$yourname = htmlspecialchars(strip_tags($_POST['name']));
// $youriin = htmlspecialchars(strip_tags($_POST['iin']));
// $yourage = htmlspecialchars(strip_tags($_POST['age']));
$yourtel = htmlspecialchars(strip_tags($_POST['phone']));
// $yourmfo = htmlspecialchars(strip_tags($_POST['mfo']));
$subject = '=?UTF-8?B?'.base64_encode('Письмо с сайта mfohelp.kz').'?=';
$message = '';
$message = $message.'Имя:'.$yourname;
// $message = $message.' ИИН: '.$youriin;
// $message = $message.' Возраст: '.$yourage;
$message = $message.' Телефон: '.$yourtel;
// $message = $message.' МФО: '.$yourmfo;

$headers= "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/plain; charset=utf8\r\n";

$headers .= "From:manager@mfohelp.kz\r\n";


if(mail($to, $subject, $message, $headers)){
    header('location: index.html');
} else{
    echo 'Unable to send email. Please try again.';
}


?>